package com.example.calculatorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static int n1,n2;
    TextView txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt=findViewById(R.id.txt_val);
        getSupportActionBar().hide();
    }

    public void btn_add(View view) {
        String val=txt.getText().toString()+"+";
        txt.setText(val);
    }

    public void btn_sub(View view) {
        String val=txt.getText().toString()+"-";
        txt.setText(val);
    }

    public void btn_mul(View view) {
        String val=txt.getText().toString()+"*";
        txt.setText(val);
    }

    public void btn_div(View view) {
        String val=txt.getText().toString()+"/";
        txt.setText(val);
    }

    public void btn_7(View view) {
        String val=txt.getText().toString()+"7";
        txt.setText(val);
    }

    public void btn_8(View view) {
        String val=txt.getText().toString()+"8";
        txt.setText(val);
    }

    public void btn_9(View view) {
        String val=txt.getText().toString()+"9";
        txt.setText(val);
    }

    public void btn_4(View view) {
        String val=txt.getText().toString()+"4";
        txt.setText(val);
    }

    public void btn_5(View view) {
        String val=txt.getText().toString()+"5";
        txt.setText(val);
    }

    public void btn_6(View view) {
        String val=txt.getText().toString()+"6";
        txt.setText(val);
    }

    public void btn_1(View view) {
        String val=txt.getText().toString()+"1";
        txt.setText(val);
    }

    public void btn_2(View view) {
        String val=txt.getText().toString()+"2";
        txt.setText(val);
    }

    public void btn_3(View view) {
        String val=txt.getText().toString()+"3";
        txt.setText(val);
    }

    public void btn_ac(View view) {
        txt.setText("");
    }

    public void btn_0(View view) {
        String val=txt.getText().toString()+"0";
        txt.setText(val);
    }

    public void btn_dot(View view) {
        String val=txt.getText().toString()+".";
        txt.setText(val);
    }

    public void btn_result(View view) {

        try {

            String expn=txt.getText().toString();;
            String s1[]={"",""};
            String s2="";
            int j=0;

            for (int i = 0; i < expn.length(); i++) {
                if (expn.charAt(i) != '+' && expn.charAt(i) != '-' && expn.charAt(i) != '*' && expn.charAt(i) != '/') {
                    s1[j] += expn.charAt(i);
                } else {
                    j++;
                    s2 = expn.charAt(i) + "";
                }
            }
            if(s2.equals("+"))
            {
                n1=Integer.parseInt(s1[0]);
                n2=Integer.parseInt(s1[1]);
                txt.setText(""+(n1+n2));

            }
            else if(s2.equals("-"))
            {
                n1=Integer.parseInt(s1[0]);
                n2=Integer.parseInt(s1[1]);
                txt.setText(""+(n1-n2));
            }
            else if(s2.equals("*"))
            {
                n1=Integer.parseInt(s1[0]);
                n2=Integer.parseInt(s1[1]);
                txt.setText(""+(n1*n2));
            }
            else
            {
                try {
                    n1=Integer.parseInt(s1[0]);
                    n2=Integer.parseInt(s1[1]);
                    txt.setText(""+(n1/n2));
                }catch (ArithmeticException e)
                {
                    Toast.makeText(this,"denominator can't be zero",Toast.LENGTH_LONG).show();
                }

            }

        }catch (Exception e)
        {
            Toast.makeText(this,"please perform any one valid arithmetic operation..",Toast.LENGTH_LONG).show();
        }


    }
}