package com.example.quizapp;

public class QAClass {

    public static String q[]=
            {
                    "Q1.MS-Word is an example of _____",
                    "Q2.Which one of the following types of waves are used in a night vision apparatus?",
                    "Q3.In which of the following festivals are boat races a special feature?",
                    "Q4.Who was the first Prime Minister of India?",
                    "Q5.The speed of light will be minimum while passing through",
                    "Q6.Who composed the Gayatri Mantra?",
                    "Q7.FFC stands for?",
                    "Q8.How many shells (cells) are there in amoeba?",
                    "Q9.Who Invented the 3-D printer?",
                    "Q10.Which of the following is known as the Diamond City of India?"
            };
    public static String opn[][]=
            {
                    {"A.An operating system","B.A processing device","C.Application software","D.An input device"},
                    {"A.Radio waves","B.Microwaves","C.Infra-red waves","D.None of the above"},
                    {"A.Rongali Bihu","B.Onam","C.Pongal","D.Navratri"},
                    {"A.Jawaharlal Nehru","B.Rajendra Prasad","C.APJ Abdul Kalam","D.Narendra Modi"},
                    {"A.water","B.vaccum","C.air","D.glass"},
                    {"A.Vishvamitra","B.Vasishtha","C.Indra","D.Parikshit"},
                    {"A.Foreign Finance Corporation","B.Film Finance Corporation","C.Federation of Football Council","D.None of the above"},
                    {"A.1","B.2","C.3","D.4"},
                    {"A.Nick Holonyak","B.Elias Howe","C.Chuck Hull","D.Christiaan Huygens"},
                    {"A.Mumbai","B.Jaipur","C.Surat","D.Panna"}
            };
    public static String ans[]=
            {
                   "C.Application software",
                    "C.Infra-red waves",
                    "C.Pongal",
                    "A.Jawaharlal Nehru",
                    "D.glass",
                    "A.Vishvamitra",
                    "B.Film Finance Corporation",
                    "A.1",
                    "C.Chuck Hull",
                    "D.Panna"
            };
}
