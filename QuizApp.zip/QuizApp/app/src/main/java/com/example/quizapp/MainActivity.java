package com.example.quizapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener  {

    TextView txt_qn;
    Button btn_a,btn_b,btn_c,btn_d;
    int score=0, current_qn=0;
    String user_ans="";

    private Handler mhandler=new Handler();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        txt_qn=findViewById(R.id.txt_question);
        btn_a=findViewById(R.id.btn_A);
        btn_b=findViewById(R.id.btn_B);
        btn_c=findViewById(R.id.btn_C);
        btn_d=findViewById(R.id.btn_D);


        btn_a.setOnClickListener(this);
        btn_b.setOnClickListener(this);
        btn_c.setOnClickListener(this);
        btn_d.setOnClickListener(this);


        questionFun();
    }


    @Override
    public void onClick(View view) {


        Button clickedButton=(Button) view;
            //user clicked button
            user_ans=clickedButton.getText().toString();
                if(user_ans.equals(QAClass.ans[current_qn]))
                {
                    clickedButton.setBackgroundColor(getResources().getColor(R.color.green));
                    score++;
                    mhandler.postDelayed(runnable,1000);

                }
                else
                {
                    clickedButton.setBackgroundColor(getResources().getColor(R.color.red));
                    mhandler.postDelayed(runnable,1000);
                }

    }

    private Runnable runnable=new Runnable() {
        @Override
        public void run() {
            current_qn++;
            questionFun();
        }
    };
    void questionFun()
    {

        if(current_qn==QAClass.q.length)
        {
            finishQuiz();
            return;
        }
        btn_a.setBackgroundColor(getResources().getColor(R.color.pink));
        btn_b.setBackgroundColor(getResources().getColor(R.color.pink));
        btn_c.setBackgroundColor(getResources().getColor(R.color.pink));
        btn_d.setBackgroundColor(getResources().getColor(R.color.pink));

        txt_qn.setText(QAClass.q[current_qn]);
        btn_a.setText(QAClass.opn[current_qn][0]);
        btn_b.setText(QAClass.opn[current_qn][1]);
        btn_c.setText(QAClass.opn[current_qn][2]);
        btn_d.setText(QAClass.opn[current_qn][3]);


    }
    void finishQuiz()
    {
        String result="";
        if(score>(QAClass.q.length)*0.5)
        {
            result="passed";
        }
        else
        {
            result="failed";
        }
        new AlertDialog.Builder(this)
                .setTitle(result)
                .setMessage("score="+score+"/"+QAClass.q.length)
                .setPositiveButton("Restart",((dialogInterface, i) -> restartQuiz()))
                .setCancelable(false)
                .show();
    }

    void restartQuiz()
    {
        score=0;
        current_qn=0;
        questionFun();
    }
}
