package com.example.unitconvertorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {



    EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText=findViewById(R.id.edt_txt);
        getSupportActionBar().hide();
    }



    public void fun_cf(View view) {

        if(editText.getText().toString().isEmpty())
        {
            editText.setError("please enter temperature");
            Toast.makeText(this,"temperature field can't be empty..",Toast.LENGTH_LONG).show();
        }
        else {
            String temp = editText.getText().toString();
            float c = Float.parseFloat(temp);
            float f = (c * 9 / 5) + 32;
            Toast.makeText(this, "Celsius to Fahrenheit=" + f, Toast.LENGTH_LONG).show();
        }
    }

    public void fun_ck(View view) {

        if(editText.getText().toString().isEmpty())
        {
            editText.setError("please enter temperature");
            Toast.makeText(this,"temperature field can't be empty..",Toast.LENGTH_LONG).show();
        }
        else {
            String temp = editText.getText().toString();
            float c = Float.parseFloat(temp);
            double k = c+273.15;
            Toast.makeText(this, "Celsius to Kelvin=" + k, Toast.LENGTH_LONG).show();
        }
    }

    public void fun_fc(View view) {


        if(editText.getText().toString().isEmpty())
        {
            editText.setError("please enter temperature");
            Toast.makeText(this,"temperature field can't be empty..",Toast.LENGTH_LONG).show();
        }
        else {
            String temp = editText.getText().toString();
            float f = Float.parseFloat(temp);
            double c = (f-32)*5/9;
            Toast.makeText(this, "Fahrenheit to celsius=" + c, Toast.LENGTH_LONG).show();
        }
    }

    public void fun_fk(View view) {

        if(editText.getText().toString().isEmpty())
        {
            editText.setError("please enter temperature");
            Toast.makeText(this,"temperature field can't be empty..",Toast.LENGTH_LONG).show();
        }
        else {
            String temp = editText.getText().toString();
            float f = Float.parseFloat(temp);
            double k = (f-32)*5/9+273.15;
            Toast.makeText(this, "Fahrenheit to Kelvin=" + k, Toast.LENGTH_LONG).show();
        }
    }

    public void fun_kc(View view) {

        if(editText.getText().toString().isEmpty())
        {
            editText.setError("please enter temperature");
            Toast.makeText(this,"temperature field can't be empty..",Toast.LENGTH_LONG).show();
        }
        else {
            String temp = editText.getText().toString();
            float k = Float.parseFloat(temp);
            double c = k-273.15;
            Toast.makeText(this, "Kelvin to Celsius=" + c, Toast.LENGTH_LONG).show();
        }

    }

    public void fun_kf(View view) {

        if(editText.getText().toString().isEmpty())
        {
            editText.setError("please enter temperature");
            Toast.makeText(this,"temperature field can't be empty..",Toast.LENGTH_LONG).show();
        }
        else {
            String temp = editText.getText().toString();
            float k = Float.parseFloat(temp);
            double f = (k-273.15)*9/5+32;
            Toast.makeText(this, "Kelvin to Fahrenheit =" + f, Toast.LENGTH_LONG).show();
        }
    }
}