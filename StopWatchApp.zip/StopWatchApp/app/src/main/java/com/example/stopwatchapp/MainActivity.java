package com.example.stopwatchapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    TextView txt_timer;
    int seconds;
    boolean start,stop;

    ImageView img_start,img_stop,img_reset;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt_timer=findViewById(R.id.txt_timer);
        img_start=findViewById(R.id.img_start);
        img_stop=findViewById(R.id.img_stop);
        img_reset=findViewById(R.id.img_reset);
        getSupportActionBar().hide();

        if(savedInstanceState!=null)
        {
            savedInstanceState.getInt("seconds");
            savedInstanceState.getBoolean("start");
            savedInstanceState.getBoolean("stop");
        }

        timerFun();
    }


    public void stop(View view) {
        start=false;
        img_start.setImageResource(R.drawable.ic_play);

    }

    public void start(View view) {
        start=true;
        img_start.setImageResource(R.drawable.ic_pause);
    }

    public void reset(View view) {
        start=false;
        seconds=0;
        img_start.setImageResource(R.drawable.ic_play);
    }



    @Override
    protected void onPause() {
        super.onPause();
        stop=start;
        start=false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(stop)
        {
            start=true;
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("seconds",seconds);
        outState.putBoolean("start",start);
        outState.putBoolean("stop",stop);
    }


    private void timerFun() {

        Handler handler=new Handler();

        handler.post(new Runnable() {
            @Override
            public void run() {
                int hrs=seconds/3600;
                int min=(seconds%3600)/60;
                int sec= seconds%60;
                String format;
                String time=String.format(Locale.getDefault(),"%d:%d:%d",hrs,min,sec);

                txt_timer.setText(time);

                if(start)
                {
                    seconds++;
                }
                handler.postDelayed(this,1000);
            }
        });
    }

}